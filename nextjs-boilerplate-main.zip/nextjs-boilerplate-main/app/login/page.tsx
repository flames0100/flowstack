"use client";
import { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Logging in with ${email}`);
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-950 text-white">
      <div className="p-8 border rounded-xl bg-gray-900 w-80 shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-center">Login</h2>
        <form onSubmit={handleLogin} className="flex flex-col gap-3">
          <input
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="p-2 rounded bg-gray-800 border border-gray-700"
          />
          <input
            placeholder="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="p-2 rounded bg-gray-800 border border-gray-700"
          />
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 py-2 rounded mt-2"
          >
            Sign In
          </button>
        </form>
      </div>
    </main>
  );
}

