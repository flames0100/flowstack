"use client";
import { useState } from "react";
import Link from "next/link";

export default function Home() {
  const [theme, setTheme] = useState("light");
  const toggleTheme = () => setTheme(theme === "light" ? "dark" : "light");

  return (
    <main
      className={`min-h-screen ${theme === "dark" ? "bg-gray-950 text-gray-100" : "bg-white text-gray-900"
        } transition-colors duration-500`}
    >
      <header className="flex justify-between items-center p-6 border-b border-gray-700">
        <h1 className="text-2xl font-bold">FlowStack</h1>
        <nav className="flex gap-4">
          <Link href="#features">Features</Link>
          <Link href="#pricing">Pricing</Link>
          <Link href="/login">Login</Link>
          <Link href="/register">Register</Link>
          <button
            onClick={toggleTheme}
            className="ml-4 border px-3 py-1 rounded-md text-sm"
          >
            {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </button>
        </nav>
      </header>

      <section className="p-10 text-center">
        <h2 className="text-5xl font-extrabold mb-4">
          Automate, Analyze, and Accelerate Your Business Flow
        </h2>
        <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
          AI-driven e-commerce SaaS that helps digital businesses scale faster
          — without managing warehouses or logistics.
        </p>
        <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-semibold">
          Get Started
        </button>
      </section>

      <section id="features" className="p-10 grid md:grid-cols-3 gap-6">
        {[
          {
            title: "AI Product Manager",
            desc: "Generate listings, pricing, and marketing descriptions automatically."
          },
          {
            title: "Smart Analytics",
            desc: "View real-time insights about customer behavior and sales performance."
          },
          {
            title: "Automation Hub",
            desc: "Connect APIs and automate routine business workflows easily."
          },
        ].map((f, i) => (
          <div key={i} className="border p-6 rounded-xl shadow hover:shadow-lg transition">
            <h3 className="font-semibold text-xl mb-2">{f.title}</h3>
            <p className="text-gray-400">{f.desc}</p>
          </div>
        ))}
      </section>

      <section id="pricing" className="p-10 bg-gray-900 text-gray-100 text-center">
        <h2 className="text-3xl font-bold mb-6">Pricing</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {[
            { plan: "Starter", price: "$0", features: ["Basic Tools", "AI Demos"] },
            { plan: "Pro", price: "$19/mo", features: ["Automation", "Custom Integrations"] },
            { plan: "Enterprise", price: "$99/mo", features: ["Full API", "Priority Support"] },
          ].map((p, i) => (
            <div key={i} className="border p-6 rounded-xl shadow hover:shadow-lg">
              <h3 className="font-semibold text-xl mb-2">{p.plan}</h3>
              <p className="text-3xl font-bold mb-4">{p.price}</p>
              <ul className="text-sm mb-4 space-y-2">
                {p.features.map((f, i) => (
                  <li key={i}>✅ {f}</li>
                ))}
              </ul>
              <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-md">
                Choose Plan
              </button>
            </div>
          ))}
        </div>
      </section>

      <footer className="p-6 border-t border-gray-700 text-center text-sm text-gray-400">
        © {new Date().getFullYear()} FlowStack. All rights reserved.
      </footer>
    </main>
  );
}
